import streamlit as st
def show():
    st.title("🎓 Smart Lecture AI")
    st.subheader("حوّل محاضراتك الصوتية إلى محتوى دراسي ذكي خلال دقائق")
    st.markdown("""
    ✔ ملخصات ذكية  
    ✔ أسئلة امتحانية  
    ✔ خرائط ذهنية  
    ✔ حفظ المحاضرات  
    """)
    st.markdown("### كيف يعمل؟")
    st.markdown("1️⃣ ارفع المحاضرة\n2️⃣ اختر نوع المخرجات\n3️⃣ استلم النتائج فورًا")
    st.markdown("### لمن هذا المنتج؟")
    st.markdown("طلاب – أساتذة – جامعات – منصات تعليمية")
    if st.button("🚀 ابدأ مجانًا"):
        st.session_state.page = "auth"
        st.experimental_rerun()
